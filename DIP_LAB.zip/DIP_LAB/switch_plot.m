x=[36 50 14]
plottype= input('Enter the plot type: ');


switch plottype
    case 'bar'
        bar(x)
        title('Bar Graph')
    case 'pie'
         pie(x)
        title('pie chart')
    case 'pie3'
        pie3(x)
        title('pie chart')
    otherwise
        disp('unexpected plot type. No plot created.')
end