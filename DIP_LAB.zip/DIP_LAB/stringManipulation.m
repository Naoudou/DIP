s='she sells sea shells on the sea shore'
findstr(s,'sea')
s1='sea land'
strcmp(s,s1)
upper(s1)
s2='SEA LAN'
lower(s2)