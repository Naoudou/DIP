clc;

clear all;
close all;
c=1;
ga=input('Enter the gamma values');
a=imread('U:\pcss28\DIP\img\lion.JPG');
x=rgb2gray(a);
x1=double(x);
y=c*(x1.^ga(1));
y1=c*(x1.^ga(2));
y2=c*(x1.^ga(3));

subplot(2,2,1),imshow(x),title('original image')
subplot(2,2,2),imshow((y),[]),title('Corected Gamma 1')
subplot(2,2,3),imshow((y),[]),title('Corected Gamma 2')
subplot(2,2,4),imshow((y),[]),title('Corected Gamma 3')


