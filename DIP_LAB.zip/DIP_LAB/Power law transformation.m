clc;

clear all;
close all;

b=imread('U:\pcss28\DIP\img\lion.JPG');
subplot(2,2,1);
imshow(b);
title('original image');
%input image in type double
r=double(b);
C=1;
S=C*log(1+r);
Temp=255/(C*log(256));
RGag=[0.04;0.10;0.20;0.40;0.67;1;1.5;2.5;5.0;10.0;25.0]
R=0:255;
figure, 
for i=1:11
    x=c*(R.^GRag(i));
    Temp =256/x(256);
    s=Temp*x;
    plot(R,s);
    title(R,s);
    xlabel('Input Intensity Lvl,r');
    ylabel('Output Intensity level, s');
    hold all
    axis([0 255 0 255])
end
    
    