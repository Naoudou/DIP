clc;
clear all;
close all;
a=imread('U:\pcss28\DIP\img\lion.jpg');
%converting the image to the tif
imwrite(a,'U:\pcss28\DIP\img\lion.tiff')
aa=imread('U:\pcss28\DIP\img\lion.tiff')
subplot(4,4,1);
imshow(aa);
title('tif img')

%Converting an img to bmp
imwrite(a,'U:\pcss28\DIP\img\lion.bmp')
aa=imread('U:\pcss28\DIP\img\lion.bmp')
subplot(4,4,2);
imshow(aa);
title('bmp img')

%Converting an img to pnp
imwrite(a,'U:\pcss28\DIP\img\lion.png')
aa=imread('U:\pcss28\DIP\img\lion.png')
subplot(4,4,3);
imshow(aa);
title('png img')

%Converting an img to gray
b=rgb2gray(a);
subplot(4,4,4);
imshow(b);
title('Gray img')

%Converting an img into an indexed img
[x,map]=gray2ind(b,16);
subplot(4,4,5);
imshow(x,map);
title('indexedimg')

%Converting to b/w
bw=im2bw(x,map,0.4);
subplot(4,4,6);
imshow(bw);
title('black an white img')

%Converting an img ro binaty then to bw
bw1=im2bw(a,0.5);
subplot(4,4,7);
imshow(bw1);
title('BW with level')

%Converting index to gray img
ig=ind2gray(x,map);
subplot(4,4,8);
imshow(ig);
title('Index to gray')

%Converting index to rgb img
irgb=ind2rgb(x,map);
subplot(4,4,9);
imshow(irgb);
title('Index to RGB img')

%Converting rgb to indexed img
[IN,map]=rgb2ind(a,32);
subplot(4,4,10);
imshow(IN,map);
title('RGB to indexed img')

