clc;
clear all;
close all;
b=imread('U:\pcss28\DIP\img\ful.JPG');
subplot(3,3,1);
imshow(b);
title('original image');
%Bit plane 8 retreiving
c=zeros(size(b))
c=double(bitset(c,8,bitget(b,8)));
subplot(3,3,2);
imshow(c);
title('Bit-plane8 Retrieved');
%Bit plane 7 retreiving
c=double(bitset(c,7,bitget(b,7)));
subplot(3,3,3);
imshow(c);
title('Bit-plane7 Retrieved');
%Bit plane 6 retreiving
c=double(bitset(c,6,bitget(b,6)));
subplot(3,3,4);
imshow(c);
title('Bit-plane6 Retrieved');
%Bit plane 5 retreiving
c=double(bitset(c,5,bitget(b,5)));
subplot(3,3,5);
imshow(c);
title('Bit-plane5 Retrieved');
%Bit plane 4 retreiving
c=double(bitset(c,4,bitget(b,4)));
subplot(3,3,6);
imshow(c);
title('Bit-plane4 Retrieved');
%Bit plane 3 retreiving
c=double(bitset(c,3,bitget(b,3)));
subplot(3,3,7);
imshow(c);
title('Bit-plane3 Retrieved');
%Bit plane 2 retreiving
c=double(bitset(c,2,bitget(b,2)));
subplot(3,3,8);
imshow(c);
title('Bit-plane2 Retrieved');
%Bit plane 1 retreiving
c=double(bitset(c,1,bitget(b,1)));
subplot(3,3,9);
imshow(c);
title('Bit-plane1 Retrieved');
