clc;
clear all;
close all;
%im=imread('U:\pcss28\DIP\img\lion.jpg');
im=rgb2gray(imread('U:\pcss28\DIP\img\lion.jpg'));
im0=imresize(im,[1024,1024]);
im1=gray2ind(im,2^8);
im2=gray2ind(im,2^7);
im3=gray2ind(im,2^6);
im4=gray2ind(im,2^5);
im5=gray2ind(im,2^4);
im6=gray2ind(im,2^3);
im7=gray2ind(im,2^2);
im8=gray2ind(im,2^1);
im9=gray2ind(im,2^0);
figure;
subplot(2,5,1);imshow(im0,[]);
subplot(2,5,2);imshow(im1,[]);
subplot(2,5,3);imshow(im2,[]);
subplot(2,5,4);imshow(im3,[]);
subplot(2,5,5);imshow(im4,[]);
subplot(2,5,6);imshow(im5,[]);
subplot(2,5,7);imshow(im6,[]);
subplot(2,5,8);imshow(im7,[]);
subplot(2,5,9);imshow(im8,[]);
subplot(2,5,10);imshow(im9,[]);


