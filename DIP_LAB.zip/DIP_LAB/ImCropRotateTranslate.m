clc;
clear all;
close all;
a=imread('U:\pcss28\DIP\img\lion.jpg');
subplot(4,2,1);
imshow(a);

b=imcrop(a);
subplot(4,2,2);
imshow(b);

c=imresize(a,0.2);
subplot(4,2,3);
imshow(c);

d=imrotate(a,-30);
subplot(4,2,4);
imshow(d);

e=imrotate(a,-30,'nearest');
subplot(4,2,5);
imshow(e);

f=imrotate(a,-20,'bilinear');
subplot(4,2,6);
imshow(f);

g=imrotate(a,20,'bicubic');
subplot(4,2,7);
imshow(g);

h=imtranslate(a,[25.3,10.1]);
subplot(4,2,8);
imshow(h);
set(gca,'visible','on')