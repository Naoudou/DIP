a=[1 2 3; 4 5 6; 7 8 9]
b=[7 8 9; 4 5 6; 1 2 3]
disp('Addition of matrix')
a+b
disp('Substration of matrix')
a-b
disp('Multiplication of matrix')
a.*b
disp('division of matrix')
8./b
5.\b
a/b
a\b
disp('POW of matrix')
3^a


% dot, inverse,cross,det,rank; operation
disp('DOT of matrix')
dot(a,b)
disp('INV of matrix')
inv(a)
disp('matrix cross products of a and b')
cross(a,b)
disp('Determinant of matrix')
det(a)
disp('Rank  of a=[1 2 3; 4 5 6; 7 8 9]')
rank(a)
disp('Rank  of b =[7 8 9; 4 5 6; 1 2 3]')
rank(b)
disp('Swaping two column')
a(:,[2,3])=a(:,[3,2])
% String manipulation
s='Matlab is simply amazing'
disp('finding the index of the first occurence')
findstr(s,'sim')
s1='fulthonn'
disp('String comparison')
strcmp(s,s1)
disp('To upper case')
upper(s1)
s2='BUT IT NEEDS TO BE CONCENTRATED'
disp('To lowercase')
lower(s2)