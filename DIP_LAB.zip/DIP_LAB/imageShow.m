m=imread('U:\pcss28\DIP\img\Ribbon-3D-Plot.JPG');
imshow(m);

subplot(2,2,1);
imshow(m);
subplot(2,2,2);
imshow(m);
subplot(2,2,3);
imshow(m);
subplot(2,2,4);
imshow(m);



