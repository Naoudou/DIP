clc;
clear all;
close all;
a=imread('U:\A Demo\Images\animal1.jfif');
d=imread('U:\A Demo\Images\animal1.jfif');
j=immultiply(a,d);
k=immultiply(a,0.5);
subplot(5,5,1);
imshow(j);title('Multiply with img')

subplot(5,5,2);
imshow(k);title('Multiply with constant')

l=imdivide(a,d);
m=imdivide(a,5);
subplot(5,5,3);
imshow(l);title('Divide with img')
subplot(5,5,4);
imshow(m);title('Divide with constant')


n=imcomplement(d);
subplot(5,5,5);
imshow(n);title('complement')

s=imadd(a,d);
r=imadd(a,50);
subplot(5,5,6);
imshow(r);title('Add with img')
subplot(5,5,7);
imshow(s);title('Add with constant')

x=imsubtract(a,d);
y=imsubtract(a,0.5);
subplot(5,5,8);
imshow(x);title('Subtract with img')
subplot(5,5,9);
imshow(y);title('Subtract with constant')

c=imabsdiff(a,d);
subplot(5,5,10);
imshow(c,[]);title('Absolute Difference')
