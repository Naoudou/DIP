clc;
clear all;
close all;

b=imread('U:\pcss28\DIP\img\ful.JPG');
subplot(3,3,1);
imshow(b);
title('original image');
%Bit plane 1
c=double(bitget(b, 1));
subplot(3,3,2);
imshow(c);
title('bit plane 1');
%Bit plane 2
c=double(bitget(b,2));
subplot(3,3,3);
imshow(c);
title('bit plane 2');
%Bit plane 3
c=double(bitget(b,3));
subplot(3,3,4);
imshow(c);
title('bit plane 3');
%Bit plane 4
c=double(bitget(b,4));
subplot(3,3,5);
imshow(c);
title('bit plane 4');
%Bit plane 5
c=double(bitget(b,5));
subplot(3,3,6);
imshow(c);
title('bit plane 5');
%Bit plane 6
c=double(bitget(b,6));
subplot(3,3,7);
imshow(c);
title('bit plane 6');
%Bit plane 7
c=double(bitget(b,7));
subplot(3,3,8);
imshow(c);
title('bit plane 7');
%Bit plane 8
c=double(bitget(b,8));
subplot(3,3,9);
imshow(c);
title('bit plane 8');
