rows=5;
cols=5;
A=ones(rows,cols);
A
for c=1:cols
    for r=1:rows
        if r==c
            A(r,c)=2;
        elseif abs(r-c)==1;
            A(r,c)=-1;
        else
            A(r,c)=0;
        end
    end
    
end
A
            
#While loop          
rows=5;
cols=5;
A=ones(rows,cols);
A
c=1;

while (c<=cols)
    r=1;
    while (r<=rows)
        if r==c
            A(r,c)=2;
        elseif abs(r-c)==1;
            A(r,c)=-1;
        else
            A(r,c)=0;
        end
        r=r+1;
    end
    c=c+1;
    
end
A