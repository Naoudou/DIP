clc;
clear all;
close all;
b=imread('U:\pcss28\DIP\img\lion.jpg');
subplot(2,2,1);
imshow(b);
title('Original img');
L = 256;

s = (L-1)-b;

subplot(2,2,2)

imshow(s); title('Img negative');

% image negative

L = 256;

c = rgb2gray(b);

s = (L-1)-c;

subplot(2,2,3)

imshow(s); title('Gray negative');

% image identity

L = 256;

s = b;

subplot(2,2,4); imshow(s); title('Img identity');

