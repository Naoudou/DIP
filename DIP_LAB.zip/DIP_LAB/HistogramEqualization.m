clc;
clear all;
close all;

a=imread('U:\pcss28\DIP\img\ful.JPG');
b=imresize(a,[200 200])
c=rgb2gray(b);
subplot(3,3,1);
imshow(b);
title('original image');

subplot(3,3,2);
imhist(c);
title('Histogram');

subplot(3,3,3);
d=histeq(c);
imshow(c);
title('Gray Image');

subplot(3,3,4);
imhist(d);
title('Histogram Equlization');


subplot(3,3,5);
imshow(d);
title('Equalized Image');